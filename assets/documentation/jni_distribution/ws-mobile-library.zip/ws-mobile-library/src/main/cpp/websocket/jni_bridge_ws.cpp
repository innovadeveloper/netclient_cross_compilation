#include <jni.h>
#include <android/log.h>
#include <memory>
#include <string>

#include "system_sora/websocket/websocket_client_factory.h"

#define LOG_TAG "SoraWS"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static JavaVM* g_jvm = nullptr;

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_jvm = vm;
    return JNI_VERSION_1_6;
}

struct WsContext {
    std::unique_ptr<system_sora::websocket::IWebSocketClient> client;
    jobject javaObj = nullptr;
    jmethodID onMessageId = nullptr;
    jmethodID onStateChangeId = nullptr;
    jmethodID onErrorId = nullptr;
};

static WsContext* toCtx(jlong handle) {
    return reinterpret_cast<WsContext*>(handle);
}

static void withEnv(const std::function<void(JNIEnv*)>& fn) {
    if (!g_jvm) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_jvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        g_jvm->AttachCurrentThread(&env, nullptr);
        attached = true;
    }
    if (env) fn(env);
    if (attached) g_jvm->DetachCurrentThread();
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeCreate(JNIEnv* env, jobject thiz) {
    auto* ctx = new WsContext();
    ctx->client = system_sora::websocket::createLwsWebSocketClient();
    ctx->javaObj = env->NewGlobalRef(thiz);

    jclass cls = env->GetObjectClass(thiz);
    ctx->onMessageId     = env->GetMethodID(cls, "onMessageFromNative",     "(Ljava/lang/String;)V");
    ctx->onStateChangeId = env->GetMethodID(cls, "onStateChangeFromNative", "(I)V");
    ctx->onErrorId       = env->GetMethodID(cls, "onErrorFromNative",       "(Ljava/lang/String;)V");

    ctx->client->setOnMessage([ctx](const std::string& msg) {
        withEnv([&](JNIEnv* e) {
            jstring jmsg = e->NewStringUTF(msg.c_str());
            e->CallVoidMethod(ctx->javaObj, ctx->onMessageId, jmsg);
            e->DeleteLocalRef(jmsg);
        });
    });

    ctx->client->setOnStateChange([ctx](system_sora::websocket::ConnectionState state) {
        withEnv([&](JNIEnv* e) {
            e->CallVoidMethod(ctx->javaObj, ctx->onStateChangeId, static_cast<jint>(state));
        });
    });

    ctx->client->setOnError([ctx](const std::string& error) {
        withEnv([&](JNIEnv* e) {
            jstring jerr = e->NewStringUTF(error.c_str());
            e->CallVoidMethod(ctx->javaObj, ctx->onErrorId, jerr);
            e->DeleteLocalRef(jerr);
        });
    });

    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeConnect(JNIEnv* env, jobject, jlong handle, jstring url) {
    auto* ctx = toCtx(handle);
    if (!ctx) return;
    const char* urlStr = env->GetStringUTFChars(url, nullptr);
    ctx->client->connect(urlStr);
    env->ReleaseStringUTFChars(url, urlStr);
}

JNIEXPORT void JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeDisconnect(JNIEnv*, jobject, jlong handle) {
    auto* ctx = toCtx(handle);
    if (ctx) ctx->client->disconnect();
}

JNIEXPORT jboolean JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeSend(JNIEnv* env, jobject, jlong handle, jstring message) {
    auto* ctx = toCtx(handle);
    if (!ctx) return JNI_FALSE;
    const char* msgStr = env->GetStringUTFChars(message, nullptr);
    bool result = ctx->client->send(msgStr);
    env->ReleaseStringUTFChars(message, msgStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeSetReconnectPolicy(
        JNIEnv*, jobject, jlong handle,
        jint initialDelayMs, jint maxDelayMs, jdouble backoffMultiplier, jint maxAttempts) {
    auto* ctx = toCtx(handle);
    if (!ctx) return;
    system_sora::websocket::ReconnectPolicy policy;
    policy.initial_delay_ms   = static_cast<uint32_t>(initialDelayMs);
    policy.max_delay_ms       = static_cast<uint32_t>(maxDelayMs);
    policy.backoff_multiplier = backoffMultiplier;
    policy.max_attempts       = maxAttempts;
    ctx->client->setReconnectPolicy(policy);
}

JNIEXPORT jint JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeState(JNIEnv*, jobject, jlong handle) {
    auto* ctx = toCtx(handle);
    if (!ctx) return 0;
    return static_cast<jint>(ctx->client->state());
}

JNIEXPORT void JNICALL
Java_com_abexa_ws_1mobile_1library_websocket_ClientWebSocket_nativeDestroy(JNIEnv* env, jobject, jlong handle) {
    auto* ctx = toCtx(handle);
    if (!ctx) return;
    ctx->client->disconnect();
    env->DeleteGlobalRef(ctx->javaObj);
    delete ctx;
}

}
