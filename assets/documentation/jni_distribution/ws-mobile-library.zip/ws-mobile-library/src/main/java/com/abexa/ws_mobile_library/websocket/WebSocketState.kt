package com.abexa.ws_mobile_library.websocket

enum class WebSocketState {
    Disconnected,
    Connecting,
    Connected,
    Reconnecting,
    Failed
}