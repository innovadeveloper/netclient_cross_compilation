package com.abexa.ws_mobile_library.websocket

class ClientWebSocket(private val listener: Listener) {

    interface Listener {
        fun onMessage(message: String)
        fun onStateChange(state: WebSocketState)
        fun onError(error: String)
    }

    private val nativeHandle: Long = nativeCreate()

    fun connect(url: String) = nativeConnect(nativeHandle, url)

    fun disconnect() = nativeDisconnect(nativeHandle)

    fun send(message: String): Boolean = nativeSend(nativeHandle, message)

    fun setReconnectPolicy(
        initialDelayMs: Int = 500,
        maxDelayMs: Int = 30000,
        backoffMultiplier: Double = 2.0,
        maxAttempts: Int = 10
    ) = nativeSetReconnectPolicy(nativeHandle, initialDelayMs, maxDelayMs, backoffMultiplier, maxAttempts)

    fun state(): WebSocketState = WebSocketState.entries[nativeState(nativeHandle)]

    fun destroy() = nativeDestroy(nativeHandle)

    private fun onMessageFromNative(message: String) = listener.onMessage(message)

    private fun onStateChangeFromNative(ordinal: Int) =
        listener.onStateChange(WebSocketState.entries[ordinal])

    private fun onErrorFromNative(error: String) = listener.onError(error)

    private external fun nativeCreate(): Long
    private external fun nativeConnect(handle: Long, url: String)
    private external fun nativeDisconnect(handle: Long)
    private external fun nativeSend(handle: Long, message: String): Boolean
    private external fun nativeSetReconnectPolicy(
        handle: Long,
        initialDelayMs: Int,
        maxDelayMs: Int,
        backoffMultiplier: Double,
        maxAttempts: Int
    )
    private external fun nativeState(handle: Long): Int
    private external fun nativeDestroy(handle: Long)

    companion object {
        init {
            System.loadLibrary("sora_jni")
        }
    }
}