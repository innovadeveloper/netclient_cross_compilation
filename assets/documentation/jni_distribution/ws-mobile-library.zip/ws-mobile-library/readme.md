# ClientWebSocket — Guía de uso (Android)

Librería para conectarse a un servidor WebSocket desde Android. Gestiona la conexión, el envío de mensajes y la reconexión automática.

## Instalación

La librería está en el artifactory de Abexa. Pide credenciales al administrador si no las tienes.

En el `build.gradle` del módulo:

```kotlin
dependencies {
    implementation("com.abexa.mobile-libraries:ws-mobile-library:1.0.0@aar")
}
```

Asegúrate de tener configurado el repositorio del artifactory en `settings.gradle` o en el `build.gradle` raíz.

## Uso rápido

```kotlin
class MainActivity : AppCompatActivity() {

    private var ws: ClientWebSocket? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ws = ClientWebSocket(object : ClientWebSocket.Listener {

            override fun onMessage(message: String) {
                Log.d("WS", "Mensaje: $message")
            }

            override fun onStateChange(state: WebSocketState) {
                Log.d("WS", "Estado: ${state.name}")
            }

            override fun onError(error: String) {
                Log.e("WS", "Error: $error")
            }
        })

        ws?.connect("wss://ejemplo.com/socket")
    }

    override fun onDestroy() {
        super.onDestroy()
        ws?.disconnect()
        ws?.destroy()
        ws = null
    }
}
```

## API

### `ClientWebSocket(listener)`

Crea el cliente. Recibe un `Listener` que será notificado de mensajes, cambios de estado y errores.

### `connect(url: String)`

Inicia la conexión. La URL debe empezar por `ws://` (sin cifrar) o `wss://` (TLS).

```kotlin
ws.connect("wss://ejemplo.com/socket")
```

### `send(message: String): Boolean`

Envía un mensaje de texto. Devuelve `true` si se encoló, `false` si no estás conectado.

```kotlin
if (ws.send("hola")) {
    Log.d("WS", "Enviado")
} else {
    Log.w("WS", "No se pudo enviar: sin conexión")
}
```

### `disconnect()`

Cierra la conexión y detiene el cliente. Bloquea hasta terminar limpiamente. Puedes volver a llamar a `connect()` después.

### `destroy()`

Libera los recursos de la librería. Obligatorio llamarlo cuando ya no uses el cliente. Después de `destroy()`, la instancia no debe reutilizarse.

```kotlin
ws.disconnect()
ws.destroy()
ws = null
```

### `state(): WebSocketState`

Consulta el estado actual de la conexión.

### `setReconnectPolicy(...)`

Configura la reconexión automática con backoff exponencial.

```kotlin
ws.setReconnectPolicy(
    initialDelayMs    = 500,     // Espera antes del primer reintento
    maxDelayMs        = 30000,   // Tope máximo entre reintentos
    backoffMultiplier = 2.0,     // Multiplicador (2.0 = duplica cada vez)
    maxAttempts       = 10       // -1 = reintentar infinitamente
)
```

Secuencia con los valores por defecto:

```
500ms → 1s → 2s → 4s → 8s → 16s → 30s → 30s → ...
```

Tras agotar `maxAttempts` se emite `onStateChange(Failed)`. Llama a este método antes de `connect()`.

## Listener

```kotlin
interface Listener {
    fun onMessage(message: String)
    fun onStateChange(state: WebSocketState)
    fun onError(error: String)
}
```

| Callback | Cuándo se llama |
|---|---|
| `onMessage(message)` | Llegó un mensaje del servidor |
| `onStateChange(state)` | Cambió el estado de la conexión |
| `onError(error)` | Ocurrió un error (texto descriptivo) |

Las callbacks llegan desde un hilo en segundo plano. Para tocar la UI usa `runOnUiThread { ... }`.

```kotlin
override fun onMessage(message: String) {
    runOnUiThread {
        binding.tvMensaje.text = message
    }
}
```

## Estados (`WebSocketState`)

| Estado | Significado |
|---|---|
| `Connecting` | Iniciando la conexión |
| `Connected` | Conectado, listo para enviar y recibir |
| `Reconnecting` | Esperando antes de un reintento |
| `Disconnected` | Cerrado por el usuario o por cierre normal |
| `Failed` | Se agotaron los intentos de reconexión |


## Errores comunes

| Síntoma | Causa probable |
|---|---|
| `send()` siempre devuelve `false` | No estás en estado `Connected` |
| Las callbacks no llegan | No llamaste a `connect()` o la URL es inválida |
| Fuga de memoria | No llamaste a `destroy()` |
| `UnsatisfiedLinkError` al iniciar | El AAR no está integrado correctamente |
| Estado pasa a `Failed` | Se agotaron los reintentos |

## Ciclo de vida

```kotlin
val ws = ClientWebSocket(listener)   // 1. Crear
ws.setReconnectPolicy(maxAttempts=5) // 2. Configurar (opcional)
ws.connect("wss://ejemplo.com/socket") // 3. Conectar
ws.send("hola")                      // 4. Usar
ws.disconnect()                      // 5. Cerrar
ws.destroy()
```

## Compatibilidad

- Android: minSdk 21+ (verificar versión exacta del AAR).
- Kotlin: 1.8+ (usa `enum entries`).
- ABIs soportadas: depende del AAR. Consultar con el equipo si necesitas `x86` (emulador) además de `arm64-v8a` / `armeabi-v7a`.